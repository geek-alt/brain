import React, { useEffect, useMemo, useRef, useState } from "react";

export default function App() {
  const API = useMemo(
    () => import.meta.env.VITE_API_URL || "http://localhost:8080",
    []
  );

  const [health, setHealth] = useState(null);
  const [busy, setBusy] = useState(false);
  const [file, setFile] = useState(null);
  const [userId, setUserId] = useState("default");
  const [model, setModel] = useState("gpt-oss-20b");
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");
  const [sources, setSources] = useState([]);
  const [error, setError] = useState(null);
  const [debugOpen, setDebugOpen] = useState(false);
  const lastReq = useRef(null);
  const lastRes = useRef(null);

  // health check
  useEffect(() => {
    const ping = async () => {
      try {
        const res = await fetch(`${API}/health`);
        const data = await res.json();
        setHealth({ ok: true, data });
      } catch (e) {
        setHealth({ ok: false, error: String(e) });
      }
    };
    ping();
  }, [API]);

  // upload file
  async function upload() {
    if (!file) return alert("Pick a file first.");
    setBusy(true); setError(null); setAnswer(""); setSources([]);

    const form = new FormData();
    form.append("file", file);
    form.append("user_id", userId);

    try {
      lastReq.current = { method: "POST", url: `${API}/upload/`, form: { user_id: userId, filename: file.name } };

      const res = await fetch(`${API}/upload/`, { method: "POST", body: form });
      const text = await res.text();

      let data;
      try { data = JSON.parse(text); } catch { data = { raw: text }; }
      lastRes.current = data;

      if (!res.ok) throw new Error(text);
      alert(data.message || "Uploaded successfully");
    } catch (e) {
      setError(String(e));
    } finally {
      setBusy(false);
    }
  }

// ask question
async function ask() {
  if (!question.trim()) return alert("Type a question first.");
  setBusy(true); setError(null); setAnswer(""); setSources([]);

  const payload = {
    question,   // ✅ plain text, not JSON string
    model,
    user_id: userId,
    level: "intermediate",
    language: "English"
  };

  try {
    lastReq.current = { method: "POST", url: `${API}/query/`, json: payload };
    console.log("Asking:", payload);

    const res = await fetch(`${API}/query/`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    const text = await res.text();
    let data;
    try { data = JSON.parse(text); } catch { data = { raw: text }; }
    lastRes.current = data;

    if (!res.ok) throw new Error(text);

    setAnswer(data.answer || "(no answer)");
    setSources(data.sources || data.source_documents || []);
  } catch (err) {
    console.error("Query error:", err);
    setError(String(err));
  } finally {
    setBusy(false);
  }
}


  // connectivity test
  async function connectivityTest() {
    try {
      const res = await fetch(`${API}/health`);
      const data = await res.json();
      alert("Backend says: " + (data.message || JSON.stringify(data)));
    } catch (e) {
      alert("Connectivity failed: " + String(e));
    }
  }

  return (
    <div className="wrap">
      <header>
        <h1>📚 RAG Q&A</h1>
        <span className="badge">API: {API}</span>
        {health?.ok ? <span className="pill">backend ✓</span> : <span className="pill">backend ?</span>}
      </header>

      <div className="grid">
        <section className="card">
          <h2>Upload documents</h2>
          <p className="muted">PDF, DOCX, or TXT. Stored per user.</p>
          <div className="row" style={{ marginTop: 8 }}>
            <input type="file" onChange={(e) => setFile(e.target.files[0])} />
          </div>
          <div className="row" style={{ marginTop: 8 }}>
            <input placeholder="user id" value={userId} onChange={(e) => setUserId(e.target.value)} />
            <button disabled={busy || !file} onClick={upload} className="btn-primary">
              {busy ? "Uploading…" : "Upload"}
            </button>
          </div>
        </section>

        <section className="card">
          <h2>Ask a question</h2>
          <div className="row" style={{ gap: 8 }}>
            <select value={model} onChange={(e) => setModel(e.target.value)}>
              <option>gpt-oss-20b</option>
              <option>llama3</option>
              <option>llama3.1</option>
              <option>mistral:7b</option>
            </select>
            <button onClick={connectivityTest}>Test Connectivity</button>
          </div>
          <textarea placeholder="Your question…" value={question} onChange={(e) => setQuestion(e.target.value)} />
          <div className="row" style={{ marginTop: 8 }}>
            <button disabled={busy || !question.trim()} onClick={ask} className="btn-primary">
              {busy ? "Thinking…" : "Ask"}
            </button>
            <button className="btn-danger" onClick={() => { setAnswer(""); setSources([]); setError(null); }}>
              Clear
            </button>
            <button onClick={() => setDebugOpen(!debugOpen)}>{debugOpen ? "Hide" : "Show"} Debug</button>
          </div>
        </section>
      </div>

      {error && (
        <div className="card" style={{ borderColor: "#7f1d1d", marginTop: 16 }}>
          <h2>Error</h2>
          <div className="answer" style={{ color: "#fecaca" }}>{String(error)}</div>
        </div>
      )}

      {answer && (
        <section className="card" style={{ marginTop: 16 }}>
          <h2>Answer</h2>
          <div className="answer">{answer}</div>
          {sources?.length > 0 && (
            <div style={{ marginTop: 10 }}>
              <h3>Sources</h3>
              <ul className="sources">
                {sources.map((s, i) => (
                  <li key={i}>
                    {s.metadata?.title || s.metadata?.source}{" "}
                    {s.metadata?.page ? `(p. ${s.metadata.page})` : ""}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </section>
      )}

      <section className="card" style={{ marginTop: 16 }}>
        <h2>Backend status</h2>
        {health?.ok ? (
          <div className="kvs">
            <div>version</div><div>{health.data?.version}</div>
            <div>embeddings</div><div>{health.data?.embeddings}</div>
            <div>cache</div><div>{String(health.data?.cache_enabled)}</div>
            <div>llm base</div><div>{health.data?.llm_base_url}</div>
            <div>origins</div><div>
              {Array.isArray(health.data?.allowed_origins)
                ? health.data.allowed_origins.join(", ")
                : String(health.data?.allowed_origins)}
            </div>
          </div>
        ) : (
          <p className="muted">Couldn’t reach /health. Is Docker up? Is your local LLM running at 127.0.0.1:1234?</p>
        )}
      </section>

      <details className="debug" open={debugOpen} style={{ marginTop: 16 }}>
        <summary><strong>Debug Console</strong> (last request/response)</summary>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginTop: 8 }}>
          <div>
            <div className="muted">Request</div>
            <pre className="answer">{JSON.stringify(lastReq.current, null, 2)}</pre>
          </div>
          <div>
            <div className="muted">Response</div>
            <pre className="answer">{JSON.stringify(lastRes.current, null, 2)}</pre>
          </div>
        </div>
      </details>
    </div>
  );
  }
